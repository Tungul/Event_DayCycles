#!/bin/sh
git pull
rm Event_DayCycles.zip
apack Event_DayCycles.zip *
git add -A
git commit
git push
